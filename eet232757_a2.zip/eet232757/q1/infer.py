import numpy as np
import pandas as pd
import pickle
from collections import Counter
import torch
import torch.nn as nn
import argparse
import torch.optim as optim
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
import csv

# Function to load GloVe embeddings
def load_glove_embeddings(file_path, embedding_dim=100):
    embeddings_index = {}
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            values = line.split()
            word = values[0]
            coefs = np.asarray(values[1:], dtype='float32')
            embeddings_index[word] = coefs
    print(f"Loaded {len(embeddings_index)} word vectors from GloVe.")
    return embeddings_index

# Data Loading and Preprocessing with GloVe
def preprocess_data_scratch(df, glove_embeddings, embedding_dim=100, max_seq_len=20):
    df = df[['text', 'airline_sentiment']].dropna()

    # Basic sentiment mapping
    sentiment_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
    df['airline_sentiment'] = df['airline_sentiment'].map(sentiment_mapping)

    # Tokenization and vocabulary creation
    def tokenize(text):
        return text.lower().split()

    vocab = Counter()
    for text in df['text']:
        vocab.update(tokenize(text))

    # Create word to index mapping based on available GloVe embeddings
    word_to_idx = {'<UNK>': 0} 
    idx = 1
    for word in glove_embeddings.keys():
        if word in vocab:
            word_to_idx[word] = idx
            idx += 1

    # Create embedding matrix with the correct size (include one extra row for '<UNK>')
    embedding_matrix = np.zeros((len(word_to_idx), embedding_dim))
    for word, i in word_to_idx.items():
        if word == '<UNK>':
            continue
        embedding_vector = glove_embeddings.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector

    def text_to_sequence(text):
        return [word_to_idx.get(word, 0) for word in tokenize(text)]

    df['text_seq'] = df['text'].apply(text_to_sequence)
    df['text_seq'] = df['text_seq'].apply(lambda x: x[:max_seq_len] + [0] * (max_seq_len - len(x)))

    data = df

    return data, embedding_matrix

# Data Loading and Preprocessing with GloVe
def preprocess_data_pytorch(df, glove_embeddings, embedding_dim=100, max_seq_len=20):
    df = df[['text', 'airline_sentiment']].dropna()

    # Basic sentiment mapping
    sentiment_mapping = {'negative': 0, 'neutral': 1, 'positive': 2}
    df['airline_sentiment'] = df['airline_sentiment'].map(sentiment_mapping)

    # Tokenization and vocabulary creation
    def tokenize(text):
        return text.lower().split()

    vocab = Counter()
    for text in df['text']:
        vocab.update(tokenize(text))

    # Create word to index mapping based on available GloVe embeddings
    word_to_idx = {'<UNK>': 0}
    idx = 1
    for word in glove_embeddings.keys():
        if word in vocab:
            word_to_idx[word] = idx
            idx += 1

    # Create embedding matrix with the correct size
    embedding_matrix = np.zeros((len(word_to_idx), embedding_dim))
    for word, i in word_to_idx.items():
        if word == '<UNK>':
            continue
        embedding_vector = glove_embeddings.get(word)
        if embedding_vector is not None:
            embedding_matrix[i] = embedding_vector

    def text_to_sequence(text):
        return [word_to_idx.get(word, 0) for word in tokenize(text)]

    df['text_seq'] = df['text'].apply(text_to_sequence)
    df['text_seq'] = df['text_seq'].apply(lambda x: x[:max_seq_len] + [0] * (max_seq_len - len(x)))

    data = df

    return data, embedding_matrix, word_to_idx


# Define the RNN model
class RNN_scratch:
    def __init__(self, input_size, hidden_size, output_size, embedding_matrix=None):
        self.embedding_matrix = embedding_matrix
        self.input_size = input_size  # Size of the embedding dimension
        self.U = np.random.randn(hidden_size, input_size) * 0.01
        self.W = np.random.randn(hidden_size, hidden_size) * 0.01
        self.V = np.random.randn(output_size, hidden_size) * 0.01
        self.bh = np.zeros((hidden_size, 1))
        self.by = np.zeros((output_size, 1))

    def forward(self, x):
        T = len(x)  # Number of time steps (length of input sequence)
        hidden_size = self.U.shape[0]
        output_size = self.V.shape[0]

        self.h = np.zeros((T, hidden_size))
        self.o = np.zeros((T, output_size))

        for t in range(T):
            # Use GloVe embedding for the input word
            xt = self.embedding_matrix[x[t]].reshape(-1, 1)

            # Update the hidden state
            self.h[t] = np.tanh(self.U @ xt + self.W @ self.h[t-1].reshape(-1, 1) + self.bh).reshape(-1)

            # Calculate the output using softmax
            self.o[t] = self.softmax(self.V @ self.h[t].reshape(-1, 1) + self.by).reshape(-1)

        return self.o[-1]  # Return the output of the last time step

    @staticmethod
    def softmax(x):
        exp_x = np.exp(x - np.max(x))
        return exp_x / np.sum(exp_x)

    def backward(self, x, y, learning_rate=0.001):
        y_one_hot = np.zeros(self.o.shape[-1])
        y_one_hot[y] = 1

        delta_y = self.o[-1] - y_one_hot

        dV = delta_y.reshape(-1, 1) @ self.h[-1].reshape(1, -1)
        dby = delta_y.reshape(-1, 1)

        delta_h = self.V.T @ delta_y.reshape(-1, 1)

        for t in reversed(range(len(x))):
            delta_h_raw = (1 - self.h[t] ** 2) * delta_h.reshape(-1)

            xt = self.embedding_matrix[x[t]].reshape(-1, 1)

            dU = delta_h_raw.reshape(-1, 1) @ xt.T
            dW = delta_h_raw.reshape(-1, 1) @ self.h[t-1].reshape(1, -1)
            dbh = delta_h_raw.reshape(-1, 1)

            self.U -= learning_rate * dU
            self.W -= learning_rate * dW
            self.V -= learning_rate * dV
            self.bh -= learning_rate * dbh
            self.by -= learning_rate * dby

            if t > 0:
                delta_h = self.W.T @ delta_h_raw.reshape(-1, 1)

class RNN_pytorch(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_size, output_size, embedding_matrix):
        super(RNN_pytorch, self).__init__()
        # Define the embedding layer with pre-trained weights
        self.embedding = nn.Embedding.from_pretrained(torch.FloatTensor(embedding_matrix), freeze=False)
        self.rnn = nn.RNN(embedding_dim, hidden_size, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = self.embedding(x)  # Look up the embeddings
        out, hidden = self.rnn(x)  # Pass through RNN
        out = self.fc(out[:, -1, :])  # Use the last time step's output
        return out



# Calculate metrics function
def calculate_metrics(y_true, y_pred):
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, average='macro', zero_division=0)
    recall = recall_score(y_true, y_pred, average='macro', zero_division=0)
    f1 = f1_score(y_true, y_pred, average='macro', zero_division=0)
    
    return accuracy, precision, recall, f1

def evaluate_and_save_results_scratch(model, test_data, output_csv="test_results.csv"):
    # Define the reverse sentiment mapping
    sentiment_reverse_mapping = {0: 'negative', 1: 'neutral', 2: 'positive'}
    
    results = []
    y_true_test = []
    y_pred_test = []

    for _, row in test_data.iterrows():
        tweet_id = row.get('tweet_id', 'N/A')  
        tweet_text = row['text']
        actual_sentiment = row['airline_sentiment']

        x = np.array(row['text_seq'])
        o = model.forward(x)
        predicted_sentiment = np.argmax(o)

        # Convert actual and predicted sentiment back to strings
        actual_sentiment_str = sentiment_reverse_mapping[actual_sentiment]
        predicted_sentiment_str = sentiment_reverse_mapping[predicted_sentiment]

        # Store for CSV output
        results.append([tweet_id, tweet_text, actual_sentiment_str, predicted_sentiment_str])
        y_true_test.append(actual_sentiment)
        y_pred_test.append(predicted_sentiment)

    # Save results to a CSV
    with open(output_csv, 'w', newline='', encoding='utf-8') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(['Tweet Id', 'Tweet Text', 'Actual Sentiment', 'Predicted Sentiment'])
        csv_writer.writerows(results)

    # Calculate test metrics
    test_accuracy, test_precision, test_recall, test_f1 = calculate_metrics(y_true_test, y_pred_test)
    print(f"Test Metrics: Accuracy = {test_accuracy:.4f}, Precision = {test_precision:.4f}, Recall = {test_recall:.4f}, F1 Score = {test_f1:.4f}")

def evaluate_and_save_results_pytorch(model, test_data, word_to_idx, output_csv="test_results.csv"):
    # Define the reverse sentiment mapping
    sentiment_reverse_mapping = {0: 'negative', 1: 'neutral', 2: 'positive'}
    
    model.eval()
    
    results = []
    y_true_test = []
    y_pred_test = []

    with torch.no_grad():
        for _, row in test_data.iterrows():
            tweet_id = row.get('tweet_id', 'N/A') 
            tweet_text = row['text']
            actual_sentiment = row['airline_sentiment']

            inputs = torch.tensor(row['text_seq'], dtype=torch.long).unsqueeze(0)
            outputs = model(inputs)
            predicted_sentiment = torch.argmax(outputs, dim=1).item()

            # Convert actual and predicted sentiment back to strings
            actual_sentiment_str = sentiment_reverse_mapping[actual_sentiment]
            predicted_sentiment_str = sentiment_reverse_mapping[predicted_sentiment]

            results.append([tweet_id, tweet_text, actual_sentiment_str, predicted_sentiment_str])
            y_true_test.append(actual_sentiment)
            y_pred_test.append(predicted_sentiment)

    # Save results to a CSV
    with open(output_csv, 'w', newline='', encoding='utf-8') as csvfile:
        csv_writer = csv.writer(csvfile)
        csv_writer.writerow(['Tweet Id', 'Tweet Text', 'Actual Sentiment', 'Predicted Sentiment'])
        csv_writer.writerows(results)

    # Calculate and print test metrics
    test_accuracy, test_precision, test_recall, test_f1 = calculate_metrics(y_true_test, y_pred_test)
    print(f"Test Metrics: Accuracy = {test_accuracy:.4f}, Precision = {test_precision:.4f}, Recall = {test_recall:.4f}, F1 Score = {test_f1:.4f}")


def main():
    parser = argparse.ArgumentParser(description="Run inference on saved models")
    parser.add_argument('--model_file', type=str, required=True, help="Path to the trained model file")
    parser.add_argument('--model_type', type=str, choices=['rnn_scratch', 'rnn_pytorch'], required=True, help="Type of model (rnn_scratch or rnn_pytorch)")
    parser.add_argument('--test_data_file', type=str, required=True, help="Path to the test dataset file")
    parser.add_argument('--output_file', type=str, required=True, help="File containing the output CSV")
    parser.add_argument('--glove_file', type=str, required=True, help="Need glove.6B.100d.txt")

    args = parser.parse_args()

    # Load GloVe embeddings
    glove_embeddings = load_glove_embeddings(args.glove_file, embedding_dim=100)

    # Load test data
    df = pd.read_csv(args.test_data_file)

    # Handle scratch model
    if args.model_type == 'rnn_scratch':
        input_size = 100  # GloVe embedding size
        hidden_size = 128
        output_size = 3
        
        test_data, embedding_matrix = preprocess_data_scratch(df, glove_embeddings, embedding_dim=100)
        
        # Create an instance of the RNN model
        model = RNN_scratch(input_size, hidden_size, output_size, embedding_matrix=embedding_matrix)
        
        with open(args.model_file, "rb") as f:
            model = pickle.load(f)

        evaluate_and_save_results_scratch(model, test_data, output_csv=args.output_file)

    # Handle PyTorch model
    elif args.model_type == 'rnn_pytorch':
        test_data, embedding_matrix, word_to_idx = preprocess_data_pytorch(df, glove_embeddings, embedding_dim=100)
        
        vocab_size = len(word_to_idx)
        embedding_dim = 100
        hidden_size = 128
        output_size = 3

        model = RNN_pytorch(vocab_size, embedding_dim, hidden_size, output_size, embedding_matrix)
        model.load_state_dict(torch.load(args.model_file))

        evaluate_and_save_results_pytorch(model, test_data, word_to_idx, output_csv=args.output_file)

if __name__ == "__main__":
    main()
    
#for scratch model
# python infer.py --model_file "part_1.1_rnn_scratch.pkl" --model_type rnn_scratch --test_data_file "Tweets_q1_main.csv" --output_file "scratch_rnn_results.csv" --glove_file "glove.6B.100d.txt"

#for pytorch model
# python infer.py --model_file "part_1.2_rnn_pytorch.pth" --model_type rnn_pytorch --test_data_file "Tweets_q1_main.csv" --output_file "pytorch_rnn_results.csv" --glove_file "glove.6B.100d.txt"
