import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from collections import Counter
import nltk
from nltk.tokenize import word_tokenize
import evaluate
import argparse

nltk.download('punkt_tab')

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# Set hyperparameters and initialize model
EMB_DIM = 100
HID_DIM = 256
N_EPOCHS = 2
LEARNING_RATE = 0.001
CLIP = 1
BATCH_SIZE = 32

# Tokenize text
def tokenize(text):
    return word_tokenize(text.lower())

# Build vocabulary
def build_vocab(tokenized_texts, max_vocab_size=10000):
    all_tokens = [token for text in tokenized_texts for token in text]
    most_common = Counter(all_tokens).most_common(max_vocab_size - 4)  # Reserve space for special tokens
    word_to_idx = {word: idx + 4 for idx, (word, _) in enumerate(most_common)}
    word_to_idx['<pad>'] = 0
    word_to_idx['<unk>'] = 1
    word_to_idx['<sos>'] = 2
    word_to_idx['<eos>'] = 3
    return word_to_idx

# Add special tokens to the tokenized summaries
def add_special_tokens(tokenized_texts, vocab):
    return [['<sos>'] + text + ['<eos>'] for text in tokenized_texts]

# Convert tokens to indices
def tokens_to_indices(tokenized_texts, vocab):
    return [[vocab.get(token, vocab['<unk>']) for token in text] for text in tokenized_texts]

# Limit sequence lengths
MAX_REVIEW_LEN = 100
MAX_SUMMARY_LEN = 30

def pad_sequences(sequences, pad_idx, max_len=None):
    if max_len is None:
        max_len = max(len(seq) for seq in sequences)
    return [seq[:max_len] + [pad_idx] * (max_len - len(seq[:max_len])) for seq in sequences]

# Add this function to load GloVe embeddings and build the embedding matrix
def load_glove_embeddings(glove_file_path, embedding_dim, vocab):
    """
    Load GloVe embeddings and create an embedding matrix for the given vocabulary.
    """
    embeddings = {}
    with open(glove_file_path, 'r', encoding='utf-8') as f:
        for line in f:
            values = line.split()
            word = values[0]
            vector = np.asarray(values[1:], dtype='float32')
            embeddings[word] = vector

    # Create an embedding matrix for the vocabulary
    embedding_matrix = np.zeros((len(vocab), embedding_dim))
    for word, idx in vocab.items():
        if word in embeddings:
            embedding_matrix[idx] = embeddings[word]
        else:
            # Assigning a random normal vector if the word is not found in the GloVe vectors
            embedding_matrix[idx] = np.random.normal(scale=0.6, size=(embedding_dim,))

    return torch.tensor(embedding_matrix, dtype=torch.float32)

# Encoder with GloVe embeddings
class Encoder(nn.Module):
    def __init__(self, input_dim, emb_dim, hidden_dim, review_embedding_matrix):
        super(Encoder, self).__init__()
        self.embedding = nn.Embedding.from_pretrained(review_embedding_matrix, freeze=False)
        self.lstm = nn.LSTM(emb_dim, hidden_dim, bidirectional=True, batch_first=True)
        self.fc_hidden = nn.Linear(hidden_dim * 2, hidden_dim)
        self.fc_cell = nn.Linear(hidden_dim * 2, hidden_dim)

    def forward(self, src):
        embedded = self.embedding(src)
        outputs, (hidden, cell) = self.lstm(embedded)
        hidden = torch.tanh(self.fc_hidden(torch.cat((hidden[-2, :, :], hidden[-1, :, :]), dim=1)))
        cell = torch.tanh(self.fc_cell(torch.cat((cell[-2, :, :], cell[-1, :, :]), dim=1)))
        return outputs, hidden.unsqueeze(0), cell.unsqueeze(0)

# decoder with GloVe embeddings
class Decoder(nn.Module):
    def __init__(self, output_dim, emb_dim, hidden_dim, summary_embedding_matrix):
        super(Decoder, self).__init__()
        self.embedding = nn.Embedding.from_pretrained(summary_embedding_matrix, freeze=False)
        self.lstm = nn.LSTM(emb_dim, hidden_dim, batch_first=True)
        self.fc_out = nn.Linear(hidden_dim, output_dim)

    def forward(self, trg, hidden, cell):
        embedded = self.embedding(trg.unsqueeze(1))
        output, (hidden, cell) = self.lstm(embedded, (hidden, cell))
        prediction = self.fc_out(output.squeeze(1))
        return prediction, hidden, cell

# Seq2Seq model
class Seq2Seq(nn.Module):
    def __init__(self, encoder, decoder):
        super(Seq2Seq, self).__init__()
        self.encoder = encoder
        self.decoder = decoder

    def forward(self, src, trg, teacher_forcing_ratio=0.6):
        batch_size = trg.shape[0]
        trg_len = trg.shape[1]
        trg_vocab_size = self.decoder.fc_out.out_features

        outputs = torch.zeros(batch_size, trg_len, trg_vocab_size).to(src.device)

        encoder_outputs, hidden, cell = self.encoder(src)

        input = trg[:, 0]

        for t in range(1, trg_len):
            output, hidden, cell = self.decoder(input, hidden, cell)
            outputs[:, t, :] = output
            top1 = output.argmax(1)
            input = trg[:, t] if torch.rand(1).item() < teacher_forcing_ratio else top1

        return outputs

def calculate_token_accuracy(predictions, targets, pad_idx):
    """Calculates token-level accuracy."""
    # Flatten both predictions and targets, and remove padding indices
    predictions_flat = predictions.view(-1)
    targets_flat = targets.view(-1)
    
    # Ignore the padding token
    mask = targets_flat != pad_idx
    correct_predictions = predictions_flat[mask] == targets_flat[mask]
    
    # Calculate accuracy
    accuracy = correct_predictions.sum().item() / mask.sum().item()
    return accuracy

def beam_search_decode(model, tensor, vocab, max_len=30, beam_width=5, device='cpu'):
    model.eval()
    
    with torch.no_grad():
        # Encode the input review
        _, hidden, cell = model.encoder(tensor)
        
        # Initialize the beams with the start-of-sequence token
        beams = [(torch.tensor([vocab['<sos>']], device=device), hidden, cell, 0.0)]
        
        for _ in range(max_len):
            new_beams = []
            for seq, hidden, cell, score in beams:
                last_token = seq[-1].unsqueeze(0)
                if last_token.item() == vocab['<eos>']:
                    new_beams.append((seq, hidden, cell, score))
                    continue

                output, hidden, cell = model.decoder(last_token, hidden, cell)
                probs = torch.softmax(output, dim=1)
                top_k_probs, top_k_indices = probs.topk(beam_width)

                for i in range(beam_width):
                    new_seq = torch.cat([seq, top_k_indices[:, i]])
                    new_score = score + torch.log(top_k_probs[0][i]).item()
                    new_beams.append((new_seq, hidden, cell, new_score))

            beams = sorted(new_beams, key=lambda x: x[3], reverse=True)[:beam_width]

        best_beam = max(beams, key=lambda x: x[3])
        best_seq = best_beam[0].tolist()

    summary_tokens = [list(vocab.keys())[list(vocab.values()).index(idx)] for idx in best_seq[1:]]
    return ' '.join(summary_tokens)

def evaluate_epoch_with_accuracy(model, iterator, criterion, pad_idx):
    model.eval()
    epoch_loss = 0
    epoch_accuracy = 0

    with torch.no_grad():
        for i in range(0, len(iterator[0]), BATCH_SIZE):
            data_batch = iterator[0][i:i + BATCH_SIZE].to(device)
            target_batch = iterator[1][i:i + BATCH_SIZE].to(device)

            output = model(data_batch, target_batch, 0)
            output = output[:, 1:].reshape(-1, output.shape[-1])
            target_batch = target_batch[:, 1:].reshape(-1)

            loss = criterion(output, target_batch)
            epoch_loss += loss.item()

            predictions = output.argmax(1).reshape(-1)
            epoch_accuracy += calculate_token_accuracy(predictions, target_batch, pad_idx)

    # Calculate average loss and accuracy
    avg_loss = epoch_loss / len(iterator[0])
    avg_accuracy = epoch_accuracy / (len(iterator[0]) // BATCH_SIZE)
    
    return avg_loss, avg_accuracy


# Define evaluation functions for BLEU and CHRF scores
bleu = evaluate.load("bleu")
chrf = evaluate.load("chrf")

def evaluate_test_set(model, test_data, test_targets, vocab, device='cpu', max_len=30, beam_width=5):
    model.eval()
    all_results = []

    with torch.no_grad():
        for i in range(0, len(test_data), BATCH_SIZE):
            data_batch = test_data[i:i + BATCH_SIZE].to(device)
            target_batch = test_targets[i:i + BATCH_SIZE]

            for j, review in enumerate(data_batch):
                tokens = review.tolist()
                indexed = [tok for tok in tokens if tok != vocab['<pad>']]
                tensor = torch.tensor(indexed).unsqueeze(0).to(device)
                predicted_summary = beam_search_decode(model, tensor, vocab, max_len, beam_width, device)

                actual_tokens = target_batch[j].tolist()
                actual_indexed = [tok for tok in actual_tokens if tok != vocab['<pad>']]
                actual_summary = ' '.join([list(vocab.keys())[list(vocab.values()).index(idx)]
                                           if idx in vocab.values() else '<unk>' for idx in actual_indexed[1:-1]])

                bleu_score = bleu.compute(predictions=[predicted_summary], references=[[actual_summary]])
                chrf_score = chrf.compute(predictions=[predicted_summary], references=[[actual_summary]])

                all_results.append({
                    "Review": ' '.join([list(vocab.keys())[list(vocab.values()).index(idx)]
                                        if idx in vocab.values() else '<unk>' for idx in indexed]),
                    "Actual Summary": actual_summary,
                    "Predicted Summary": predicted_summary,
                    "BLEU Score": bleu_score['bleu'],
                    "CHRF Score": chrf_score['score']
                })

    return all_results


def main():
    parser = argparse.ArgumentParser(description="Run inference on saved models")
    parser.add_argument('--model_file', type=str, required=True, help="Path to the trained model file")
    parser.add_argument('--beam_size', type=int, required=True, help="beam size")
    parser.add_argument('--model_type', type=str, choices=['lstm_lstm', 'lstm_lstm_attn'], required=True, help="Type of model (lstm_lstm or lstm_lstm_attn)")
    parser.add_argument('--test_data_file', type=str, required=True, help="Path to the test dataset file")
    parser.add_argument('--output_file', type=str, required=True, help="File containing the output CSV")
    parser.add_argument('--glove_file', type=str, required=True, help="Need glove.6B.100d.txt")

    args = parser.parse_args()

    if args.model_type == 'lstm_lstm':
        

        # Load the dataset (in CSV format with 'Text' and 'Summary' columns)
        df = pd.read_csv(args.test_data_file)
        df['Text'] = df['Text'].astype(str)
        df['Summary'] = df['Summary'].astype(str)
        df['Text'].fillna('', inplace=True)
        df['Summary'].fillna('', inplace=True)

        # Tokenize and build vocabulary for reviews and summaries
        tokenized_reviews = [tokenize(text) for text in df['Text'].values]
        tokenized_summaries = [tokenize(summary) for summary in df['Summary'].values]
        review_vocab = build_vocab(tokenized_reviews)
        summary_vocab = build_vocab(tokenized_summaries)

        # Add special tokens to the tokenized summaries
        tokenized_summaries = add_special_tokens(tokenized_summaries, summary_vocab)

        indexed_reviews = tokens_to_indices(tokenized_reviews, review_vocab)
        indexed_summaries = tokens_to_indices(tokenized_summaries, summary_vocab)

        # Pad and truncate sequences
        padded_reviews = pad_sequences(indexed_reviews, review_vocab['<pad>'], MAX_REVIEW_LEN)
        padded_summaries = pad_sequences(indexed_summaries, summary_vocab['<pad>'], MAX_SUMMARY_LEN)

        # test data is the loaded file
        test_data, y_test = padded_reviews, padded_summaries

        # Convert these splits into tensors
        X_test = torch.tensor(test_data, dtype=torch.long)
        y_test = torch.tensor(y_test, dtype=torch.long)

        # Define the file path and embedding dimension
        embedding_dim = 100

        # Load GloVe embeddings for review and summary vocabularies
        review_embedding_matrix = load_glove_embeddings(args.glove_file, embedding_dim, review_vocab)
        summary_embedding_matrix = load_glove_embeddings(args.glove_file, embedding_dim, summary_vocab)

        INPUT_DIM = len(review_vocab)
        OUTPUT_DIM = len(summary_vocab)

        encoder = Encoder(INPUT_DIM, EMB_DIM, HID_DIM, review_embedding_matrix).to(device)
        decoder = Decoder(OUTPUT_DIM, EMB_DIM, HID_DIM, summary_embedding_matrix).to(device)
        model = Seq2Seq(encoder, decoder).to(device)

        # Load the state dictionary (weights) into the model
        model.load_state_dict(torch.load(args.model_file))
        model.eval()

        # Evaluate the model on the test set
        test_results = evaluate_test_set(model, X_test, y_test, summary_vocab, device, max_len=30, beam_width=args.beam_size)

        # Create a DataFrame from the results
        test_results_df = pd.DataFrame(test_results, columns=["Review", "Actual Summary", "Predicted Summary", "BLEU Score", "CHRF Score"])

        # Save the DataFrame to a CSV file
        test_results_df.to_csv(args.output_file, index=False)

        print(f"Test set results saved.")

    elif args.model_type == 'lstm_lstm_attn':
        # not implemented this
        exit()

if __name__ == "__main__":
    main()
    
    
# for lstm_lstm model
# python infer.py --model_file "lstm_lstm.pth" --beam_size 5 --model_type lstm_lstm --test_data_file "Reviews_q2_main.csv" --output_file "lstm_lstm_results.csv" --glove_file "glove.6B.100d.txt"






































